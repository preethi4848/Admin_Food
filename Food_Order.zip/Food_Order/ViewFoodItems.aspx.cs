﻿using AdminDLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Food_Order
{
    public partial class ViewFoodItems : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)//fills the listbox only first time.
            {
                //Create the object of the Dll Component
                var obj = DataFactory.GetFoodManager();
                //Call the method to get all employees
                List<Food> data = obj.GetAllFood();
                //Add the names to the listbox from the employees.  
                lstNames.DataSource = data;
                lstNames.DataTextField = "Food_Name";
                lstNames.DataValueField = "Food_Id";
                lstNames.DataBind();
            }
        }

        protected void lstNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            var obj = DataFactory.GetFoodManager();
            //Call the method to get all employees
            List<Food> data = obj.GetAllFood();
            var selectedValue = lstNames.SelectedValue;
            foreach (var temp in data)
            {
                if (temp.Food_Id.ToString() == selectedValue)
                {
                    txtId.Text = temp.Food_Id.ToString();
                  
                    txtName.Text = temp.Food_Name;
                    txtImage.ImageUrl = temp.Image;
                    
                    txtPrice.Text = temp.Price.ToString();
                    txtCount.Text = temp.Count.ToString();
                    return;
                }
            }
        }
    }
}
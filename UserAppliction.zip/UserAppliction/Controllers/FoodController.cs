﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UserAppliction.Models;

namespace UserAppliction.Controllers
{
    public class FoodController : Controller
    {
        // GET: ViewFood
        public ActionResult ViewFood()
        {
            var context = new Food_OrderingEntities1();
            var model = context.tbl_food.ToList();
            return View(model);
    
        }
    }
}